package GuiaTuristico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuiaTuristicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
